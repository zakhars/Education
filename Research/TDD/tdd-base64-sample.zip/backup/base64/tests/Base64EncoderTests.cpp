#include <base64/codec.h>

#include <ut/assert.h>
#include <ut/test.h>

using namespace std;

namespace base64
{
	namespace tests
	{
		begin_test_suite( Base64EncoderTests )
			test( EncodingThreeZeroesProducesFourBase64Zeroes )
			{
				// INIT
				unsigned char buffer[] = { 0, 0, 0, };

				// ACT
				string r = base64encode(buffer, _countof(buffer));

				// ASSERT
				assert_equal("AAAA", r);
			}


			test( FirstSixBitsAreTranslatedIntoFirstBase64Digit )
			{
				// INIT
				unsigned char buffer[] = { 0x04, 0x00, 0x00, };

				// ACT
				string r = base64encode(buffer, _countof(buffer));

				// ASSERT
				assert_equal("BAAA", r);

				// INIT
				buffer[0] = 0x08;

				// ACT
				r = base64encode(buffer, _countof(buffer));

				// ASSERT
				assert_equal("CAAA", r);

				// INIT
				buffer[0] = 0xFC;

				// ACT
				r = base64encode(buffer, _countof(buffer));

				// ASSERT
				assert_equal("/AAA", r);
			}
		end_test_suite
	}
}

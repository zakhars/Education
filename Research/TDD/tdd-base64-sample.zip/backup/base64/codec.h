#pragma once

#include <string>

namespace base64
{
	std::string base64encode(const unsigned char* buffer, size_t count);
}

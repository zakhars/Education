#include <base64/codec.h>

namespace base64
{
	std::string base64encode(const unsigned char* buffer, size_t count)
	{
		return "AAAA";
	}
}

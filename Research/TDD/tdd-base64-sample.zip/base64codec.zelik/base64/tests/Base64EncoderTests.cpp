#include <base64/codec.h>

#include <ut/assert.h>
#include <ut/test.h>

using namespace std;

namespace base64
{
   namespace tests
   {
      begin_test_suite( Base64EncoderTests )
         test( ThreeZeroBytesAreEncodedAs4Base64ZeroDigits )
         {
            // INIT
            vector<uint8_t> buffer { 0, 0, 0 };

            // ACT
            auto r = base64encode(buffer);

            // ASSERT
            assert_equal("AAAA", r);
         }


         test( ThreeFFsAreEncodedIntoFourSlashes )
         {
            // INIT
            vector<uint8_t> buffer { 0xFF, 0xFF, 0xFF };

            // ACT
            auto r = base64encode(buffer);

            // ASSERT
            assert_equal("////", r);
         }


         test( Highest6BitsOfFirstByteAreEncodedIntoBase64DigitBase64ZeroAndPadding )
         {
            // ACT / ASSERT
            assert_equal("AA==", base64encode({ 0 << 2, }));
            assert_equal("BA==", base64encode({ 1 << 2, }));
            assert_equal("aA==", base64encode({ 26 << 2, }));
            assert_equal("+A==", base64encode({ 62 << 2, }));
            assert_equal("/A==", base64encode({ 63 << 2, }));
         }

         test( EncodeSameDigitIntoDifferentBase64Places )
         {
            // ACT / ASSERT
            assert_equal("BAAA", base64encode({ 1 << 2, 0, 0 }));
            assert_equal("ABAA", base64encode({ 0, 1 << 4, 0}));
            assert_equal("AABA", base64encode({ 0, 0, 1 << 6}));
            assert_equal("AAAB", base64encode({ 0, 0, 1 }));
            assert_equal("/AAA", base64encode({ 63 << 2, 0, 0 }));
            assert_equal("A/AA", base64encode({ 3, 0xF0, 0}));
            assert_equal("AA/A", base64encode({ 0, 0x0F, 3 << 6}));
            assert_equal("AAA/", base64encode({ 0, 0, 0x3F }));
         }


         test( PaddingIsAddedAccordinglyToBufferSize )
         {
            // ACT / ASSERT
            assert_equal("AAA=", base64encode({ 0, 0, }));
         }


         test( IncompleteSequenceIsFullyEncoded )
         {
            // ACT / ASSERT
            assert_equal("/w==", base64encode({ 0xFF, }));
            assert_equal("AP8=", base64encode({ 0x00, 0xFF, }));
         }

         test( EmptyBufferIsEmptyBase64 )
         {
            // ACT / ASSERT
            assert_equal("", base64encode({ }));
         }


         test( ConsequentTriadsAreEncodedAsTheFirstOne )
         {
            assert_equal("AAAABA==", base64encode({ 0, 0, 0, 1 << 2, }));
            assert_equal("////BA==", base64encode({ 0xFF, 0xFF, 0xFF, 1 << 2, }));
            assert_equal("AAAAAAAABA==", base64encode({ 0, 0, 0, 0, 0, 0, 1 << 2, }));
            assert_equal("////////BA==", base64encode({ 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 1 << 2, }));
         }


         test( Base64EncodeHandlesLongSequences )
         {
            // INIT
            vector<uint8_t> buffer(9999999);

            // ACT / ASSERT (must not crash)
            auto r = base64encode(buffer);

            // ASSERT
            assert_equal(buffer.size() / 3 * 4, r.size());
         }
      end_test_suite
   }
}

#include <base64/codec.h>

using namespace std;

namespace base64
{
   namespace
   {
      char c_base64Alphabet[] = {
         'A',
         'B',
         'C',
         'D',
         'E',
         'F',
         'G',
         'H',
         'I',
         'J',
         'K',
         'L',
         'M',
         'N',
         'O',
         'P',
         'Q',
         'R',
         'S',
         'T',
         'U',
         'V',
         'W',
         'X',
         'Y',
         'Z',
         'a',
         'b',
         'c',
         'd',
         'e',
         'f',
         'g',
         'h',
         'i',
         'j',
         'k',
         'l',
         'm',
         'n',
         'o',
         'p',
         'q',
         'r',
         's',
         't',
         'u',
         'v',
         'w',
         'x',
         'y',
         'z',
         '0',
         '1',
         '2',
         '3',
         '4',
         '5',
         '6',
         '7',
         '8',
         '9',
         '+',
         '/',
      };

      char firstDigit(uint8_t firstByte)
      {  return c_base64Alphabet[firstByte >> 2];   }

      char secondDigit(uint8_t firstByte, uint8_t secondByte)
      {  return c_base64Alphabet[((firstByte & 0x03) << 4) + (secondByte >> 4)];   }

      char thirdDigit(uint8_t secondByte, uint8_t thirdByte)
      {  return c_base64Alphabet[(thirdByte >> 6) + ((secondByte & 0x0F) << 2)];   }

      char fourthDigit(uint8_t thirdByte)
      {  return c_base64Alphabet[thirdByte & 0x3F];   }

      void base64encode_triad(string& encoded, const uint8_t* buffer, size_t size)
      {
         encoded += firstDigit(buffer[0]);

         if (size < 2)
         {
            encoded += secondDigit(buffer[0], 0);
            encoded += "==";
            return;
         }

         encoded += secondDigit(buffer[0], buffer[1]);

         if (size < 3)
         {
            encoded += thirdDigit(buffer[1], 0);
            encoded += "=";
            return;
         }

         encoded += thirdDigit(buffer[1], buffer[2]);
         encoded += fourthDigit(buffer[2]);
      }
   }

   string base64encode(const vector<uint8_t>& buffer)
   {
      string encoded;

      for (size_t index = 0; index < buffer.size(); index += 3)
         base64encode_triad(encoded, &buffer[index], buffer.size() - index);
      return encoded;
   }
}

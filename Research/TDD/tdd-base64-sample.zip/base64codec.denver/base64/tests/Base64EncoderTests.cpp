#include <base64/codec.h>

#include <ut/assert.h>
#include <ut/test.h>

using namespace std;

namespace base64
{
   namespace tests
   {
      begin_test_suite( Base64EncoderTests )

         static string Base64Alphabet()
         {
            string alphabet;

            for (char i = 'A'; i <= 'Z'; ++i)
               alphabet += i;
            for (char i = 'a'; i <= 'z'; ++i)
               alphabet += i;
            for (char i = '0'; i <= '9'; ++i)
               alphabet += i;
            alphabet += "+/";
            return alphabet;
         }


         test( EmptyByteSequenceEncodedIntoEmptyString )
         {
            // INIT
            vector<uint8_t> seq;

            // ACT
            const auto encoded = base64_encode(seq);

            // ASSERT
            assert_equal("", encoded);
         }


         test( ThreeZeroBytesAreEncodedIntoFourBase64Zeroes )
         {
            // ACT
            const auto encoded = base64_encode({ 0, 0, 0 });

            // ASSERT
            assert_equal("AAAA", encoded);
         }


         test( OneZeroByteIsEncodedIntoTwoBase64ZeroesAndPadding )
         {
            // ACT
            const auto encoded = base64_encode({ 0 });

            // ASSERT
            assert_equal("AA==", encoded);
         }


         test( TwoZeroesAreEncodedIntoThreeBase64ZeroesAndPadding )
         {
            // ACT
            const auto encoded = base64_encode({ 0, 0 });

            // ASSERT
            assert_equal("AAA=", encoded);
         }


         test( FirstBase64DigitIsEncodedInSequencesOfDifferentLength )
         {
            // ACT
            auto encoded = base64_encode({
               1 << 2,
            });

            // ASSERT
            assert_equal("BA==", encoded);

            // ACT
            encoded = base64_encode({
               1 << 2,
               0
            });

            // ASSERT
            assert_equal("BAA=", encoded);

            // ACT
            encoded = base64_encode({
               1 << 2,
               0,
               0
            });

            // ASSERT
            assert_equal("BAAA", encoded);
         }


         test( FirstDigitIsEncodedAccordinglyToBase64Alphabet )
         {
            // INIT
            const auto base64alphabet = Base64Alphabet();

            for (uint8_t i = 0; i != 64; ++i)
            {
               // ACT
               auto encoded = base64_encode({ static_cast<uint8_t>(i << 2) });

               // ASSERT
               assert_equal(string(1, base64alphabet[i]) + "A==", encoded);
            }
         }


         test( SecondDigitIsEncodedForTwoBytes )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x10,
            });

            // ASSERT
            assert_equal("ABA=", encoded);

            // ACT
            encoded = base64_encode({
               0x03,
               0xF0,
            });

            // ASSERT
            assert_equal("A/A=", encoded);
         }


         test( SecondDigitIsEncodedForThreeBytes )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x10,
               0x00,
            });

            // ASSERT
            assert_equal("ABAA", encoded);

            // ACT
            encoded = base64_encode({
               0x03,
               0xF0,
               0x00,
            });

            // ASSERT
            assert_equal("A/AA", encoded);
         }


         test( SecondDigitIsEncodedForOneByte )
         {
            // ACT
            auto encoded = base64_encode({
               0x01,
            });

            // ASSERT
            assert_equal("AQ==", encoded);

            // ACT
            encoded = base64_encode({
               0x03,
            });

            // ASSERT
            assert_equal("Aw==", encoded);
         }


         test( ThirdDigitIsEncodedForThreeBytes )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x00,
               0xC0,
            });

            // ASSERT
            assert_equal("AADA", encoded);

            // ACT
            encoded = base64_encode({
               0x00,
               0x0F,
               0x80,
            });

            // ASSERT
            assert_equal("AA+A", encoded);
         }


         test( ThirdDigitIsEncodedForTwoBytes )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x01,
            });

            // ASSERT
            assert_equal("AAE=", encoded);

            // ACT
            encoded = base64_encode({
               0x00,
               0x0F,
            });

            // ASSERT
            assert_equal("AA8=", encoded);
         }


         test( FourthDigitIsEncoded )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x00,
               0x3B
            });

            // ASSERT
            assert_equal("AAA7", encoded);
         }


         test( SixthBytesSequencesIsEncodedIntoEightBase64Digits )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x00,
               0xC0,
               0x00,
               0x00,
               0x3B
            });

            // ASSERT
            assert_equal("AADAAAA7", encoded);

            // ACT
            encoded = base64_encode({
               0x00,
               0x00,
               0xC0,
               0x00,
               0x00,
               0x00
            });

            // ASSERT
            assert_equal("AADAAAAA", encoded);
         }


         test( LargeBufferIsEncodedNormally )
         {
            // INIT
            vector<uint8_t> buffer(9999999, 0);

            // ACT
            const auto r = base64_encode(buffer);

            // ASSERT
            assert_equal(buffer.size() / 3 * 4, r.size());
         }


         test( PaddedLongSequenceIsCorrectlyEncoded )
         {
            // ACT
            auto encoded = base64_encode({
               0x00,
               0x00,
               0xC0,
               0x00,
               0x01,
            });

            // ASSERT
            assert_equal("AADAAAE=", encoded);
         }
      end_test_suite
   }
}

#include <base64/codec.h>


#include <ut/assert.h>
#include <ut/test.h>

using namespace std;

namespace base64
{
   namespace tests
   {
      begin_test_suite( Base64IntegrationTests )
         test( Base64EncodingDecodingProvidesGivenInput )
         {
            // INIT
            vector<uint8_t> sequence1 { 0x01, 0x02, 0x00, 0xF0, };
            vector<uint8_t> sequence2 { 0x01, 0x02, 0x00, 0xF0, 0x02, 0x00, 0x02, 0x00, 0xF0, 0xF0 };

            // ACT / ASSERT
            assert_equal(sequence1, get<0>(base64_decode(base64_encode(sequence1))));
            assert_equal(sequence2, get<0>(base64_decode(base64_encode(sequence2))));
         }
      end_test_suite
   }
}

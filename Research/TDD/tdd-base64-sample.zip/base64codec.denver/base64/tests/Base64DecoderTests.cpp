#include <base64/codec.h>

#include <ut/assert.h>
#include <ut/test.h>

using namespace std;

namespace base64
{
   namespace tests
   {
      begin_test_suite( Base64DecoderTests )
         test( EmptyStringIsDecodedAsEmptySequence )
         {
            // ACT
            auto result = base64_decode("");

            // ASSERT
            assert_is_empty(get<0>(result));
         }


         test( FourBase64ZeroesAreDecodedAsThreeZeroBytes )
         {
            // ACT
            auto result = base64_decode("AAAA");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0, 0 }), get<0>(result));
         }


         test( TwoBase64ZeroesAreDecodedAsSingleZeroByte )
         {
            // ACT
            auto result = base64_decode("AA==");

            // ASSERT
            assert_equal((vector<uint8_t> { 0 }), get<0>(result));
         }


         test( ThreeBase64ZeroesAreDecodedAsTwoZeroBytes )
         {
            // ACT
            auto result = base64_decode("AAA=");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0 }), get<0>(result));
         }


         test( FirstBase64CapitalDigitIsDecodedInto6MostSignificantBitsInTheFirstByteOfResult )
         {
            // ACT
            for (char digit = 'A'; digit <= 'Z'; ++digit)
            {
               auto result = base64_decode(digit + string("A=="));

             // ASSERT
               auto expected = vector<uint8_t> { static_cast<uint8_t>((digit - 'A') << 2) };

               assert_equal(expected, get<0>(result));
               assert_is_true(get<1>(result));
            }
         }


         test( FirstBase64SmallDigitIsDecodedInto6MostSignificantBitsInTheFirstByteOfResult )
         {
            // ACT
            for (char digit = 'a'; digit <= 'z'; ++digit)
            {
               auto result = base64_decode(digit + string("A=="));

             // ASSERT
               auto expected = vector<uint8_t> { static_cast<uint8_t>((digit - 'a' + 26) << 2) };

               assert_equal(expected, get<0>(result));
               assert_is_true(get<1>(result));
            }
         }


         test( FirstBase64NumberDigitIsDecodedInto6MostSignificantBitsInTheFirstByteOfResult )
         {
            // ACT
            for (char digit = '0'; digit <= '9'; ++digit)
            {
               auto result = base64_decode(digit + string("A=="));

             // ASSERT
               auto expected = vector<uint8_t> { static_cast<uint8_t>((digit - '0' + 52) << 2) };

               assert_equal(expected, get<0>(result));
               assert_is_true(get<1>(result));
            }
         }


         test( InvalidBase64CharacterFailsDecoding )
         {
            // INIT
            for (uint8_t digit = 1; digit <= 254; ++digit)
            {
               if (!('A' <= digit && digit <= 'Z') && !('a' <= digit && digit <= 'z')
                  && !('0' <= digit && digit <= '9') && digit != '+' && digit != '/')
               {
            // INIT
                  auto result = base64_decode(static_cast<char>(digit) + string("A=="));

            // ASSERT
                  assert_is_false(get<1>(result));
               }
            }
         }


         test( PlusAndSlashAsFirstBase64DigitsAreDecodedIntoFirstByteOfResult )
         {
            // ACT
            auto result = base64_decode("+A==");

            // ASSERT
            auto expected = vector<uint8_t> { static_cast<uint8_t>(62 << 2) };

            assert_equal(expected, get<0>(result));
            assert_is_true(get<1>(result));

            // ACT
            result = base64_decode("/A==");

            // ASSERT
            expected = vector<uint8_t> { static_cast<uint8_t>(63 << 2) };

            assert_equal(expected, get<0>(result));
            assert_is_true(get<1>(result));
         }


         test( LastBase64DigitIsDecodedInto6LeastSignificantBitsInThirdByte )
         {
            // ACT
            auto result = base64_decode("AAAJ");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0, 9 }), get<0>(result));

            // ACT
            result = base64_decode("AAA/");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0, 63 }), get<0>(result));
         }


         test( FirstByteIsFullyDecodedFromTwoBase64Digits )
         {
            // ACT
            auto result = base64_decode("+Q==");

            // ASSERT
            assert_equal((vector<uint8_t> { 0xF9 }), get<0>(result));
         }


         test( SecondByteIsFullyDecodedFromMiddleTwoBase64Digits )
         {
            // ACT
            auto result = base64_decode("APk=");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0xF9 }), get<0>(result));

            // ACT
            result = base64_decode("APkA");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0xF9, 0 }), get<0>(result));
         }


         test( ThirdByteIsFullyDecodedFromLastTwoBase64Digits )
         {
            // ACT
            auto result = base64_decode("AACD");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0, 0x83 }), get<0>(result));
         }


         test( LongerThanQuadDigitsAreDecodedIntoCorrespondingSequence )
         {
            // ACT
            auto result = base64_decode("AAAA""AAAA");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0, 0, 0, 0, 0 }), get<0>(result));

            // ACT
            result = base64_decode("AAAA""AAAA""AA==");

            // ASSERT
            assert_equal((vector<uint8_t> { 0, 0, 0, 0, 0, 0, 0 }), get<0>(result));
         }
      end_test_suite
   }
}

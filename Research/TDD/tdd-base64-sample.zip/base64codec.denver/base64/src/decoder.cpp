#include <base64/codec.h>

using namespace std;

namespace base64
{
   namespace
   {
      uint8_t decode_base64_digit(char digit)
      {
         if (digit == '+')
            return 62;
         else if (digit == '/')
            return 63;
         else if ('a' <= digit && digit <= 'z')
            return digit -'a' + 26;
         else if ('A' <= digit && digit <= 'Z')
            return digit -'A';
         else if ('0' <= digit && digit <= '9')
            return digit - '0' + 52;
         throw 0;
      }

      bool is_terminator(char symbol)
      {  return symbol == '=';   }
   }

   tuple<vector<uint8_t>, bool> base64_decode(const string& input_sequence)
   {
      vector<uint8_t> result;

      try
      {
         for (size_t pos = 0; pos < input_sequence.size(); pos += 4)
         {
            auto sequence = input_sequence.data() + pos;

            // 1st byte fully decoded
            result.push_back((decode_base64_digit(sequence[0]) << 2) + (decode_base64_digit(sequence[1]) >> 4));

            // attempt 2nd byte
            if (!is_terminator(sequence[2]))
               result.push_back((decode_base64_digit(sequence[2]) >> 2) + (decode_base64_digit(sequence[1]) << 4));

            // attempt 3rd byte
            if (!is_terminator(sequence[3]))
               result.push_back(decode_base64_digit(sequence[3]) + (decode_base64_digit(sequence[2]) << 6));
         }
      }
      catch (int)
      {
         return make_tuple(result, false);
      }
      return make_tuple(result, true);
   }
}

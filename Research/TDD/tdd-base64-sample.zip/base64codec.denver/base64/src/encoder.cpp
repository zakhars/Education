#include <base64/codec.h>

using namespace std;

namespace base64
{
   namespace
   {
      char base64_digit_encode(int v)
      {  return "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[v]; }

      char encode_second_digit(uint8_t first_byte, uint8_t second_byte)
      {  return base64_digit_encode(((0x03 & first_byte) << 4) + (second_byte >> 4));  }

      char encode_third_digit(uint8_t second_byte, uint8_t third_byte)
      {  return base64_digit_encode(((0x0F & second_byte) << 2) + (third_byte >> 6));  }

      void base64_encode_triad(string& encoded, const uint8_t* buffer, size_t count)
      {
         encoded += base64_digit_encode(buffer[0] >> 2);

         if (count == 1)
         {
            encoded += encode_second_digit(buffer[0], 0);
            encoded += "==";
            return;
         }

         encoded += encode_second_digit(buffer[0], buffer[1]);

         if (count == 2)
         {
            encoded += encode_third_digit(buffer[1], 0);
            encoded += '=';
            return;
         }

         encoded += encode_third_digit(buffer[1], buffer[2]);
         encoded += base64_digit_encode(0x3F & buffer[2]);
      }
   }

   string base64_encode(const vector<uint8_t>& buffer)
   {
      string encoded;

      encoded.reserve(buffer.size() / 3 * 4 + 2);
      for (size_t index = 0; index < buffer.size(); index += 3)
         base64_encode_triad(encoded, &buffer[index], buffer.size() - index);
      return encoded;
   }
}

#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <tuple>

namespace base64
{
   std::string base64_encode(const std::vector<std::uint8_t>& buffer);

   std::tuple<std::vector<std::uint8_t>, bool> base64_decode(const std::string& encoded_sequence);
}
